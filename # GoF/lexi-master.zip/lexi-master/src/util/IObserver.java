package util;

public interface IObserver {
	void updateObserver(ModelChangedEventArgs args);
}
