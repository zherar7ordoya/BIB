package headfirst.designpatterns.factory.challenge;

public class Zone {
	String displayName;
	int offset;
	public String getDisplayName() { return displayName; }
	public int getOffset() { return offset; }
}