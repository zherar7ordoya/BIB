package headfirst.designpatterns.factory.pizzaaf;

public class MozzarellaCheese implements Cheese {

	public String toString() {
		return "Shredded Mozzarella";
	}
}
