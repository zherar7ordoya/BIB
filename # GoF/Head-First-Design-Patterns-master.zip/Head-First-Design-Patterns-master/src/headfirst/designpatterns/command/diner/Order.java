package headfirst.designpatterns.command.diner;

@FunctionalInterface
public interface Order {
	public void orderUp();
}
