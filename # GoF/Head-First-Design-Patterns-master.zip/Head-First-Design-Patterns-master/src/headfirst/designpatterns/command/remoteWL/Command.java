package headfirst.designpatterns.command.remoteWL;

@FunctionalInterface
public interface Command {
	public void execute();
}
