English: This project is a simulation of events in Java objects trying to simulate events and delegates like the C# language to facilitate communication between objects. Through launch an event and act through a listener.

Español: Este proyecto es una simulación de eventos de objetos en Java intentando simular los eventos y delegados del lenguaje C# que facilitan la comunicación entre objetos. A traves de lanzar un eveto y actuar mediante un escuchador(listener).

Example of execution of the class App.java:

![alt tag](http://i.imgur.com/zcBakMw.jpg)
