package ui;

public interface IMainFrame {
}
