package util;

import java.awt.Graphics;

public interface IMainWindow {
	Graphics getApplicationGraphics();
}
