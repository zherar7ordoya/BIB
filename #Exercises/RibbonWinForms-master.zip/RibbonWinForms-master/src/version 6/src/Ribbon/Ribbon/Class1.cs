﻿using System;

namespace Ribbon
{
    public class Class1
    {
    }
}
