using System.ComponentModel;

namespace RibbonDemo
{
    partial class BlackForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
           this.SuspendLayout();
           // 
           // ribbon1
           // 
           // 
           // 
           // 
           this.ribbon1.OrbDropDown.BorderRoundness = 8;
           this.ribbon1.OrbDropDown.Location = new System.Drawing.Point(0, 0);
           this.ribbon1.OrbDropDown.Name = "";
           this.ribbon1.OrbDropDown.Size = new System.Drawing.Size(527, 474);
           this.ribbon1.OrbDropDown.TabIndex = 0;
           this.ribbon1.Size = new System.Drawing.Size(1211, 138);
           // 
           // BlackForm
           // 
           this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
           this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
           this.BackColor = System.Drawing.Color.DimGray;
           this.ClientSize = new System.Drawing.Size(1211, 264);
           this.Name = "BlackForm";
           this.Text = "BlackForm";
           this.ResumeLayout(false);

        }

        #endregion

    }
}