﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace RibbonDemo
{
   public partial class QiosCaptionTest : Qios.DevSuite.Components.Ribbon.QRibbonForm
   {
      public QiosCaptionTest()
      {
         InitializeComponent();
      }
   }
}
