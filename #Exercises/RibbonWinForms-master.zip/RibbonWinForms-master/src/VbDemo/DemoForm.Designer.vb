﻿Imports System.ComponentModel
Imports Microsoft.VisualBasic.CompilerServices

<DesignerGenerated()>
Partial Class DemoForm
    Inherits RibbonForm

    'Form overrides dispose to clean up the component list.
    <DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As ComponentResourceManager = New ComponentResourceManager(GetType(DemoForm))
        Me.ribbon1 = New Ribbon()
        Me.ribbonOrbMenuItem1 = New RibbonOrbMenuItem()
        Me.ribbonOrbMenuItem2 = New RibbonOrbMenuItem()
        Me.ribbonOrbMenuItem3 = New RibbonOrbMenuItem()
        Me.ribbonOrbMenuItem4 = New RibbonOrbMenuItem()
        Me.ribbonSeparator6 = New RibbonSeparator()
        Me.ribbonDescriptionMenuItem1 = New RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem2 = New RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem3 = New RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem4 = New RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem5 = New RibbonDescriptionMenuItem()
        Me.ribbonSeparator3 = New RibbonSeparator()
        Me.ribbonOrbMenuItem5 = New RibbonOrbMenuItem()
        Me.ribbonSeparator5 = New RibbonSeparator()
        Me.ribbonDescriptionMenuItem6 = New RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem7 = New RibbonDescriptionMenuItem()
        Me.ribbonDescriptionMenuItem8 = New RibbonDescriptionMenuItem()
        Me.ribbonOrbMenuItem6 = New RibbonOrbMenuItem()
        Me.ribbonOrbMenuItem7 = New RibbonOrbMenuItem()
        Me.ribbonOrbMenuItem8 = New RibbonOrbMenuItem()
        Me.ribbonSeparator4 = New RibbonSeparator()
        Me.ribbonOrbMenuItem9 = New RibbonOrbMenuItem()
        Me.ribbonOrbOptionButton1 = New RibbonOrbOptionButton()
        Me.ribbonOrbOptionButton2 = New RibbonOrbOptionButton()
        Me.ribbonOrbRecentItem1 = New RibbonOrbRecentItem()
        Me.ribbonOrbRecentItem2 = New RibbonOrbRecentItem()
        Me.ribbonOrbRecentItem3 = New RibbonOrbRecentItem()
        Me.ribbonButton42 = New RibbonButton()
        Me.ribbonButton43 = New RibbonButton()
        Me.ribbonButton44 = New RibbonButton()
        Me.ribbonButton45 = New RibbonButton()
        Me.ribbonTab1 = New RibbonTab()
        Me.ribbonPanel1 = New RibbonPanel()
        Me.ribbonButton1 = New RibbonButton()
        Me.ribbonButton2 = New RibbonButton()
        Me.ribbonButton3 = New RibbonButton()
        Me.ribbonButton4 = New RibbonButton()
        Me.ribbonSeparator7 = New RibbonSeparator()
        Me.ribbonButton5 = New RibbonButton()
        Me.ribbonButton6 = New RibbonButton()
        Me.ribbonButton7 = New RibbonButton()
        Me.ribbonPanel2 = New RibbonPanel()
        Me.ribbonItemGroup1 = New RibbonItemGroup()
        Me.ribbonComboBox1 = New RibbonComboBox()
        Me.ribbonComboBox2 = New RibbonComboBox()
        Me.ribbonItemGroup2 = New RibbonItemGroup()
        Me.ribbonButton8 = New RibbonButton()
        Me.ribbonButton9 = New RibbonButton()
        Me.ribbonItemGroup3 = New RibbonItemGroup()
        Me.ribbonButton10 = New RibbonButton()
        Me.ribbonItemGroup4 = New RibbonItemGroup()
        Me.ribbonButton11 = New RibbonButton()
        Me.ribbonButton12 = New RibbonButton()
        Me.ribbonButton13 = New RibbonButton()
        Me.ribbonButton14 = New RibbonButton()
        Me.ribbonButton15 = New RibbonButton()
        Me.ribbonButton16 = New RibbonButton()
        Me.ribbonButton17 = New RibbonButton()
        Me.ribbonButton18 = New RibbonButton()
        Me.ribbonButton19 = New RibbonButton()
        Me.ribbonButton20 = New RibbonButton()
        Me.ribbonButton21 = New RibbonButton()
        Me.ribbonButton22 = New RibbonButton()
        Me.ribbonItemGroup5 = New RibbonItemGroup()
        Me.ribbonColorChooser1 = New RibbonColorChooser()
        Me.ribbonColorChooser2 = New RibbonColorChooser()
        Me.ribbonPanel3 = New RibbonPanel()
        Me.ribbonItemGroup6 = New RibbonItemGroup()
        Me.ribbonButton23 = New RibbonButton()
        Me.ribbonButton24 = New RibbonButton()
        Me.ribbonButton25 = New RibbonButton()
        Me.ribbonItemGroup7 = New RibbonItemGroup()
        Me.ribbonButton26 = New RibbonButton()
        Me.ribbonButton27 = New RibbonButton()
        Me.ribbonItemGroup8 = New RibbonItemGroup()
        Me.ribbonButton29 = New RibbonButton()
        Me.ribbonItemGroup9 = New RibbonItemGroup()
        Me.ribbonButton28 = New RibbonButton()
        Me.ribbonItemGroup10 = New RibbonItemGroup()
        Me.ribbonColorChooser3 = New RibbonColorChooser()
        Me.ribbonButton31 = New RibbonButton()
        Me.ribbonItemGroup11 = New RibbonItemGroup()
        Me.ribbonButton30 = New RibbonButton()
        Me.ribbonItemGroup12 = New RibbonItemGroup()
        Me.ribbonButton32 = New RibbonButton()
        Me.ribbonButton33 = New RibbonButton()
        Me.ribbonButton34 = New RibbonButton()
        Me.ribbonButton35 = New RibbonButton()
        Me.ribbonPanel4 = New RibbonPanel()
        Me.lst = New RibbonButtonList()
        Me.ribbonButton36 = New RibbonButton()
        Me.ribbonButton37 = New RibbonButton()
        Me.itemColors = New RibbonButton()
        Me.ribbonButton38 = New RibbonButton()
        Me.ribbonSeparator2 = New RibbonSeparator()
        Me.ribbonButton41 = New RibbonButton()
        Me.ribbonButton39 = New RibbonButton()
        Me.ribbonSeparator1 = New RibbonSeparator()
        Me.ribbonButton40 = New RibbonButton()
        Me.ribbonPanel5 = New RibbonPanel()
        Me.ribbonButton46 = New RibbonButton()
        Me.ribbonButton47 = New RibbonButton()
        Me.ribbonButton48 = New RibbonButton()
        Me.ribbonButton49 = New RibbonButton()
        Me.ribbonButton50 = New RibbonButton()
        Me.ribbonButton51 = New RibbonButton()
        Me.ribbonButton52 = New RibbonButton()
        Me.panelMain = New Panel()
        Me.label4 = New Label()
        Me.label3 = New Label()
        Me.label2 = New Label()
        Me.label1 = New Label()
        Me.panelMain.SuspendLayout()
        Me.SuspendLayout()
        '
        'ribbon1
        '
        Me.ribbon1.Font = New Font("Segoe UI", 9.0!)
        Me.ribbon1.Location = New Point(0, 0)
        Me.ribbon1.Minimized = False
        Me.ribbon1.Name = "ribbon1"
        '
        '
        '
        Me.ribbon1.OrbDropDown.BorderRoundness = 8
        Me.ribbon1.OrbDropDown.Location = New Point(0, 0)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem1)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem2)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem3)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem4)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonSeparator3)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem5)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem6)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem7)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem8)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonSeparator4)
        Me.ribbon1.OrbDropDown.MenuItems.Add(Me.ribbonOrbMenuItem9)
        Me.ribbon1.OrbDropDown.Name = ""
        Me.ribbon1.OrbDropDown.OptionItems.Add(Me.ribbonOrbOptionButton1)
        Me.ribbon1.OrbDropDown.OptionItems.Add(Me.ribbonOrbOptionButton2)
        Me.ribbon1.OrbDropDown.RecentItems.Add(Me.ribbonOrbRecentItem1)
        Me.ribbon1.OrbDropDown.RecentItems.Add(Me.ribbonOrbRecentItem2)
        Me.ribbon1.OrbDropDown.RecentItems.Add(Me.ribbonOrbRecentItem3)
        Me.ribbon1.OrbDropDown.Size = New Size(527, 474)
        Me.ribbon1.OrbDropDown.TabIndex = 0
        Me.ribbon1.OrbStyle = RibbonOrbStyle.Office_2013
        Me.ribbon1.OrbText = "FILE"
        '
        '
        '
        Me.ribbon1.QuickAccessToolbar.Items.Add(Me.ribbonButton42)
        Me.ribbon1.QuickAccessToolbar.Items.Add(Me.ribbonButton43)
        Me.ribbon1.QuickAccessToolbar.Items.Add(Me.ribbonButton44)
        Me.ribbon1.QuickAccessToolbar.Items.Add(Me.ribbonButton45)
        Me.ribbon1.RibbonTabFont = New Font("Trebuchet MS", 9.0!)
        Me.ribbon1.Size = New Size(928, 138)
        Me.ribbon1.TabIndex = 0
        Me.ribbon1.Tabs.Add(Me.ribbonTab1)
        Me.ribbon1.TabsMargin = New Padding(12, 26, 20, 0)
        Me.ribbon1.Text = "ribbon1"
        Me.ribbon1.ThemeColor = RibbonTheme.Blue
        '
        'ribbonOrbMenuItem1
        '
        Me.ribbonOrbMenuItem1.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem1.Image = My.Resources.Resources.close32
        Me.ribbonOrbMenuItem1.Name = "ribbonOrbMenuItem1"
        Me.ribbonOrbMenuItem1.SmallImage = My.Resources.Resources.close32
        Me.ribbonOrbMenuItem1.Text = "New"
        '
        'ribbonOrbMenuItem2
        '
        Me.ribbonOrbMenuItem2.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem2.Image = My.Resources.Resources.open32
        Me.ribbonOrbMenuItem2.Name = "ribbonOrbMenuItem2"
        Me.ribbonOrbMenuItem2.SmallImage = My.Resources.Resources.open32
        Me.ribbonOrbMenuItem2.Text = "Open"
        '
        'ribbonOrbMenuItem3
        '
        Me.ribbonOrbMenuItem3.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem3.Image = My.Resources.Resources.save32
        Me.ribbonOrbMenuItem3.Name = "ribbonOrbMenuItem3"
        Me.ribbonOrbMenuItem3.SmallImage = My.Resources.Resources.save32
        Me.ribbonOrbMenuItem3.Text = "Save"
        '
        'ribbonOrbMenuItem4
        '
        Me.ribbonOrbMenuItem4.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem4.DropDownItems.Add(Me.ribbonSeparator6)
        Me.ribbonOrbMenuItem4.DropDownItems.Add(Me.ribbonDescriptionMenuItem1)
        Me.ribbonOrbMenuItem4.DropDownItems.Add(Me.ribbonDescriptionMenuItem2)
        Me.ribbonOrbMenuItem4.DropDownItems.Add(Me.ribbonDescriptionMenuItem3)
        Me.ribbonOrbMenuItem4.DropDownItems.Add(Me.ribbonDescriptionMenuItem4)
        Me.ribbonOrbMenuItem4.DropDownItems.Add(Me.ribbonDescriptionMenuItem5)
        Me.ribbonOrbMenuItem4.Image = My.Resources.Resources.saveas32
        Me.ribbonOrbMenuItem4.Name = "ribbonOrbMenuItem4"
        Me.ribbonOrbMenuItem4.SmallImage = My.Resources.Resources.save32
        Me.ribbonOrbMenuItem4.Style = RibbonButtonStyle.SplitDropDown
        Me.ribbonOrbMenuItem4.Text = "Save as"
        '
        'ribbonSeparator6
        '
        Me.ribbonSeparator6.Name = "ribbonSeparator6"
        Me.ribbonSeparator6.Text = "Save a copy of the document"
        '
        'ribbonDescriptionMenuItem1
        '
        Me.ribbonDescriptionMenuItem1.Description = "Save the document in the default file format"
        Me.ribbonDescriptionMenuItem1.DescriptionBounds = New Rectangle(46, 24, 315, 28)
        Me.ribbonDescriptionMenuItem1.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem1.Image = My.Resources.Resources.worddocument32
        Me.ribbonDescriptionMenuItem1.Name = "ribbonDescriptionMenuItem1"
        Me.ribbonDescriptionMenuItem1.SmallImage = My.Resources.Resources.worddocument32
        Me.ribbonDescriptionMenuItem1.Text = "Word Document"
        '
        'ribbonDescriptionMenuItem2
        '
        Me.ribbonDescriptionMenuItem2.Description = "Save the document as a template that can be used to format future documents"
        Me.ribbonDescriptionMenuItem2.DescriptionBounds = New Rectangle(46, 76, 315, 28)
        Me.ribbonDescriptionMenuItem2.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem2.Image = My.Resources.Resources.wordtemplate32
        Me.ribbonDescriptionMenuItem2.Name = "ribbonDescriptionMenuItem2"
        Me.ribbonDescriptionMenuItem2.SmallImage = My.Resources.Resources.wordtemplate32
        Me.ribbonDescriptionMenuItem2.Text = "Word Template"
        '
        'ribbonDescriptionMenuItem3
        '
        Me.ribbonDescriptionMenuItem3.Description = "Save a copy of the document that is fully compatible with  Word 93 - 2007"
        Me.ribbonDescriptionMenuItem3.DescriptionBounds = New Rectangle(46, 128, 315, 28)
        Me.ribbonDescriptionMenuItem3.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem3.Image = My.Resources.Resources.word2003doc32
        Me.ribbonDescriptionMenuItem3.Name = "ribbonDescriptionMenuItem3"
        Me.ribbonDescriptionMenuItem3.SmallImage = My.Resources.Resources.word2003doc32
        Me.ribbonDescriptionMenuItem3.Text = "Word 97 - 2003"
        '
        'ribbonDescriptionMenuItem4
        '
        Me.ribbonDescriptionMenuItem4.Description = "Learn about add-ins to save to other formats like XPS or PDF"
        Me.ribbonDescriptionMenuItem4.DescriptionBounds = New Rectangle(46, 180, 315, 28)
        Me.ribbonDescriptionMenuItem4.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem4.Image = My.Resources.Resources.addons32
        Me.ribbonDescriptionMenuItem4.Name = "ribbonDescriptionMenuItem4"
        Me.ribbonDescriptionMenuItem4.SmallImage = My.Resources.Resources.addons32
        Me.ribbonDescriptionMenuItem4.Text = "Find add-ins for other file formats"
        '
        'ribbonDescriptionMenuItem5
        '
        Me.ribbonDescriptionMenuItem5.Description = "Open the save as dialog to choose between the all available formats to save."
        Me.ribbonDescriptionMenuItem5.DescriptionBounds = New Rectangle(46, 232, 315, 28)
        Me.ribbonDescriptionMenuItem5.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem5.Image = My.Resources.Resources.saveas321
        Me.ribbonDescriptionMenuItem5.Name = "ribbonDescriptionMenuItem5"
        Me.ribbonDescriptionMenuItem5.SmallImage = My.Resources.Resources.saveas321
        Me.ribbonDescriptionMenuItem5.Text = "Other Formats"
        '
        'ribbonSeparator3
        '
        Me.ribbonSeparator3.Name = "ribbonSeparator3"
        '
        'ribbonOrbMenuItem5
        '
        Me.ribbonOrbMenuItem5.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem5.DropDownItems.Add(Me.ribbonSeparator5)
        Me.ribbonOrbMenuItem5.DropDownItems.Add(Me.ribbonDescriptionMenuItem6)
        Me.ribbonOrbMenuItem5.DropDownItems.Add(Me.ribbonDescriptionMenuItem7)
        Me.ribbonOrbMenuItem5.DropDownItems.Add(Me.ribbonDescriptionMenuItem8)
        Me.ribbonOrbMenuItem5.Image = My.Resources.Resources.print32
        Me.ribbonOrbMenuItem5.Name = "ribbonOrbMenuItem5"
        Me.ribbonOrbMenuItem5.SmallImage = My.Resources.Resources.print32
        Me.ribbonOrbMenuItem5.Style = RibbonButtonStyle.SplitDropDown
        Me.ribbonOrbMenuItem5.Text = "Print"
        '
        'ribbonSeparator5
        '
        Me.ribbonSeparator5.Name = "ribbonSeparator5"
        Me.ribbonSeparator5.Text = "Preview and print the document"
        '
        'ribbonDescriptionMenuItem6
        '
        Me.ribbonDescriptionMenuItem6.Description = "Select a printer, number of copies and other options before printing"
        Me.ribbonDescriptionMenuItem6.DescriptionBounds = New Rectangle(46, 45, 315, 28)
        Me.ribbonDescriptionMenuItem6.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem6.Image = My.Resources.Resources.print321
        Me.ribbonDescriptionMenuItem6.Name = "ribbonDescriptionMenuItem6"
        Me.ribbonDescriptionMenuItem6.SmallImage = My.Resources.Resources.print321
        Me.ribbonDescriptionMenuItem6.Text = "Print"
        '
        'ribbonDescriptionMenuItem7
        '
        Me.ribbonDescriptionMenuItem7.Description = "Send the document directly to the printer without making changes"
        Me.ribbonDescriptionMenuItem7.DescriptionBounds = New Rectangle(46, 97, 315, 28)
        Me.ribbonDescriptionMenuItem7.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem7.Image = My.Resources.Resources.printquick32
        Me.ribbonDescriptionMenuItem7.Name = "ribbonDescriptionMenuItem7"
        Me.ribbonDescriptionMenuItem7.SmallImage = My.Resources.Resources.printquick32
        Me.ribbonDescriptionMenuItem7.Text = "Quick Print"
        '
        'ribbonDescriptionMenuItem8
        '
        Me.ribbonDescriptionMenuItem8.Description = "Preview and make changes to pages before printing."
        Me.ribbonDescriptionMenuItem8.DescriptionBounds = New Rectangle(46, 149, 315, 28)
        Me.ribbonDescriptionMenuItem8.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonDescriptionMenuItem8.Image = My.Resources.Resources.printpreview32
        Me.ribbonDescriptionMenuItem8.Name = "ribbonDescriptionMenuItem8"
        Me.ribbonDescriptionMenuItem8.SmallImage = My.Resources.Resources.printpreview32
        Me.ribbonDescriptionMenuItem8.Text = "Print Preview"
        '
        'ribbonOrbMenuItem6
        '
        Me.ribbonOrbMenuItem6.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem6.Image = My.Resources.Resources.prepare32
        Me.ribbonOrbMenuItem6.Name = "ribbonOrbMenuItem6"
        Me.ribbonOrbMenuItem6.SmallImage = My.Resources.Resources.prepare32
        Me.ribbonOrbMenuItem6.Text = "Prepare"
        '
        'ribbonOrbMenuItem7
        '
        Me.ribbonOrbMenuItem7.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem7.Image = My.Resources.Resources.send32
        Me.ribbonOrbMenuItem7.Name = "ribbonOrbMenuItem7"
        Me.ribbonOrbMenuItem7.SmallImage = My.Resources.Resources.send32
        Me.ribbonOrbMenuItem7.Text = "Send"
        '
        'ribbonOrbMenuItem8
        '
        Me.ribbonOrbMenuItem8.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem8.Image = My.Resources.Resources.publish32
        Me.ribbonOrbMenuItem8.Name = "ribbonOrbMenuItem8"
        Me.ribbonOrbMenuItem8.SmallImage = My.Resources.Resources.publish32
        Me.ribbonOrbMenuItem8.Text = "Publish"
        '
        'ribbonSeparator4
        '
        Me.ribbonSeparator4.Name = "ribbonSeparator4"
        '
        'ribbonOrbMenuItem9
        '
        Me.ribbonOrbMenuItem9.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonOrbMenuItem9.Image = My.Resources.Resources.close32
        Me.ribbonOrbMenuItem9.Name = "ribbonOrbMenuItem9"
        Me.ribbonOrbMenuItem9.SmallImage = My.Resources.Resources.close32
        Me.ribbonOrbMenuItem9.Text = "Close"
        '
        'ribbonOrbOptionButton1
        '
        Me.ribbonOrbOptionButton1.Image = My.Resources.Resources.exit16
        Me.ribbonOrbOptionButton1.Name = "ribbonOrbOptionButton1"
        Me.ribbonOrbOptionButton1.SmallImage = My.Resources.Resources.exit16
        Me.ribbonOrbOptionButton1.Text = "Exit Ribbon Demo"
        '
        'ribbonOrbOptionButton2
        '
        Me.ribbonOrbOptionButton2.Image = My.Resources.Resources.options16
        Me.ribbonOrbOptionButton2.Name = "ribbonOrbOptionButton2"
        Me.ribbonOrbOptionButton2.SmallImage = My.Resources.Resources.open16
        Me.ribbonOrbOptionButton2.Text = "Ribbon Demo Options"
        '
        'ribbonOrbRecentItem1
        '
        Me.ribbonOrbRecentItem1.Image = CType(resources.GetObject("ribbonOrbRecentItem1.Image"), Image)
        Me.ribbonOrbRecentItem1.Name = "ribbonOrbRecentItem1"
        Me.ribbonOrbRecentItem1.SmallImage = CType(resources.GetObject("ribbonOrbRecentItem1.SmallImage"), Image)
        Me.ribbonOrbRecentItem1.Text = "Recent Document 1"
        '
        'ribbonOrbRecentItem2
        '
        Me.ribbonOrbRecentItem2.Image = CType(resources.GetObject("ribbonOrbRecentItem2.Image"), Image)
        Me.ribbonOrbRecentItem2.Name = "ribbonOrbRecentItem2"
        Me.ribbonOrbRecentItem2.SmallImage = CType(resources.GetObject("ribbonOrbRecentItem2.SmallImage"), Image)
        Me.ribbonOrbRecentItem2.Text = "Recent Document 2"
        '
        'ribbonOrbRecentItem3
        '
        Me.ribbonOrbRecentItem3.Image = CType(resources.GetObject("ribbonOrbRecentItem3.Image"), Image)
        Me.ribbonOrbRecentItem3.Name = "ribbonOrbRecentItem3"
        Me.ribbonOrbRecentItem3.SmallImage = CType(resources.GetObject("ribbonOrbRecentItem3.SmallImage"), Image)
        Me.ribbonOrbRecentItem3.Text = "Recent Document 3"
        '
        'ribbonButton42
        '
        Me.ribbonButton42.Image = CType(resources.GetObject("ribbonButton42.Image"), Image)
        Me.ribbonButton42.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton42.Name = "ribbonButton42"
        Me.ribbonButton42.SmallImage = My.Resources.Resources.save16
        Me.ribbonButton42.Text = "ribbonButton42"
        Me.ribbonButton42.ToolTip = "Save"
        '
        'ribbonButton43
        '
        Me.ribbonButton43.Image = CType(resources.GetObject("ribbonButton43.Image"), Image)
        Me.ribbonButton43.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton43.Name = "ribbonButton43"
        Me.ribbonButton43.SmallImage = My.Resources.Resources.printquick16
        Me.ribbonButton43.Text = "ribbonButton43"
        Me.ribbonButton43.ToolTip = "Print"
        '
        'ribbonButton44
        '
        Me.ribbonButton44.Image = CType(resources.GetObject("ribbonButton44.Image"), Image)
        Me.ribbonButton44.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton44.Name = "ribbonButton44"
        Me.ribbonButton44.SmallImage = My.Resources.Resources.undo16
        Me.ribbonButton44.Text = "ribbonButton44"
        Me.ribbonButton44.ToolTip = "Undo"
        '
        'ribbonButton45
        '
        Me.ribbonButton45.Image = CType(resources.GetObject("ribbonButton45.Image"), Image)
        Me.ribbonButton45.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton45.Name = "ribbonButton45"
        Me.ribbonButton45.SmallImage = My.Resources.Resources.open16
        Me.ribbonButton45.Text = "ribbonButton45"
        Me.ribbonButton45.ToolTip = "Open"
        '
        'ribbonTab1
        '
        Me.ribbonTab1.Name = "ribbonTab1"
        Me.ribbonTab1.Panels.Add(Me.ribbonPanel1)
        Me.ribbonTab1.Panels.Add(Me.ribbonPanel2)
        Me.ribbonTab1.Panels.Add(Me.ribbonPanel3)
        Me.ribbonTab1.Panels.Add(Me.ribbonPanel4)
        Me.ribbonTab1.Panels.Add(Me.ribbonPanel5)
        Me.ribbonTab1.Text = "START"
        '
        'ribbonPanel1
        '
        Me.ribbonPanel1.Image = My.Resources.Resources.paste16
        Me.ribbonPanel1.Items.Add(Me.ribbonButton1)
        Me.ribbonPanel1.Items.Add(Me.ribbonSeparator7)
        Me.ribbonPanel1.Items.Add(Me.ribbonButton5)
        Me.ribbonPanel1.Items.Add(Me.ribbonButton6)
        Me.ribbonPanel1.Items.Add(Me.ribbonButton7)
        Me.ribbonPanel1.Name = "ribbonPanel1"
        Me.ribbonPanel1.Text = "Clipboard"
        '
        'ribbonButton1
        '
        Me.ribbonButton1.DropDownItems.Add(Me.ribbonButton2)
        Me.ribbonButton1.DropDownItems.Add(Me.ribbonButton3)
        Me.ribbonButton1.DropDownItems.Add(Me.ribbonButton4)
        Me.ribbonButton1.Image = My.Resources.Resources.paste32
        Me.ribbonButton1.MinSizeMode = RibbonElementSizeMode.Large
        Me.ribbonButton1.Name = "ribbonButton1"
        Me.ribbonButton1.SmallImage = My.Resources.Resources.paste16
        Me.ribbonButton1.Style = RibbonButtonStyle.SplitDropDown
        Me.ribbonButton1.Text = "Paste"
        '
        'ribbonButton2
        '
        Me.ribbonButton2.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton2.Image = CType(resources.GetObject("ribbonButton2.Image"), Image)
        Me.ribbonButton2.Name = "ribbonButton2"
        Me.ribbonButton2.SmallImage = My.Resources.Resources.paste16
        Me.ribbonButton2.Text = "Paste"
        '
        'ribbonButton3
        '
        Me.ribbonButton3.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton3.Image = CType(resources.GetObject("ribbonButton3.Image"), Image)
        Me.ribbonButton3.Name = "ribbonButton3"
        Me.ribbonButton3.SmallImage = My.Resources.Resources.pastespecial16
        Me.ribbonButton3.Text = "Paste special..."
        '
        'ribbonButton4
        '
        Me.ribbonButton4.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton4.Image = CType(resources.GetObject("ribbonButton4.Image"), Image)
        Me.ribbonButton4.Name = "ribbonButton4"
        Me.ribbonButton4.SmallImage = My.Resources.Resources.pastelink16
        Me.ribbonButton4.Text = "Paste as link"
        '
        'ribbonSeparator7
        '
        Me.ribbonSeparator7.Name = "ribbonSeparator7"
        '
        'ribbonButton5
        '
        Me.ribbonButton5.Image = CType(resources.GetObject("ribbonButton5.Image"), Image)
        Me.ribbonButton5.MaxSizeMode = RibbonElementSizeMode.Medium
        Me.ribbonButton5.Name = "ribbonButton5"
        Me.ribbonButton5.SmallImage = My.Resources.Resources.cut16
        Me.ribbonButton5.Text = "Cut"
        '
        'ribbonButton6
        '
        Me.ribbonButton6.Image = CType(resources.GetObject("ribbonButton6.Image"), Image)
        Me.ribbonButton6.MaxSizeMode = RibbonElementSizeMode.Medium
        Me.ribbonButton6.Name = "ribbonButton6"
        Me.ribbonButton6.SmallImage = My.Resources.Resources.copy16
        Me.ribbonButton6.Text = "Copy"
        '
        'ribbonButton7
        '
        Me.ribbonButton7.Image = CType(resources.GetObject("ribbonButton7.Image"), Image)
        Me.ribbonButton7.MaxSizeMode = RibbonElementSizeMode.Medium
        Me.ribbonButton7.Name = "ribbonButton7"
        Me.ribbonButton7.SmallImage = My.Resources.Resources.copyformat16
        Me.ribbonButton7.Text = "Paste"
        '
        'ribbonPanel2
        '
        Me.ribbonPanel2.FlowsTo = RibbonPanelFlowDirection.Right
        Me.ribbonPanel2.Image = My.Resources.Resources.fontcolor16
        Me.ribbonPanel2.Items.Add(Me.ribbonItemGroup1)
        Me.ribbonPanel2.Items.Add(Me.ribbonItemGroup2)
        Me.ribbonPanel2.Items.Add(Me.ribbonItemGroup3)
        Me.ribbonPanel2.Items.Add(Me.ribbonItemGroup4)
        Me.ribbonPanel2.Items.Add(Me.ribbonItemGroup5)
        Me.ribbonPanel2.Name = "ribbonPanel2"
        Me.ribbonPanel2.Text = "Font"
        '
        'ribbonItemGroup1
        '
        Me.ribbonItemGroup1.DrawBackground = False
        Me.ribbonItemGroup1.Items.Add(Me.ribbonComboBox1)
        Me.ribbonItemGroup1.Items.Add(Me.ribbonComboBox2)
        Me.ribbonItemGroup1.Name = "ribbonItemGroup1"
        Me.ribbonItemGroup1.Text = "ribbonItemGroup1"
        '
        'ribbonComboBox1
        '
        Me.ribbonComboBox1.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonComboBox1.Name = "ribbonComboBox1"
        Me.ribbonComboBox1.Text = "ribbonComboBox1"
        Me.ribbonComboBox1.TextBoxText = "Calibri"
        Me.ribbonComboBox1.TextBoxWidth = 160
        '
        'ribbonComboBox2
        '
        Me.ribbonComboBox2.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonComboBox2.Name = "ribbonComboBox2"
        Me.ribbonComboBox2.Text = "ribbonComboBox2"
        Me.ribbonComboBox2.TextBoxText = "11"
        Me.ribbonComboBox2.TextBoxWidth = 40
        '
        'ribbonItemGroup2
        '
        Me.ribbonItemGroup2.Items.Add(Me.ribbonButton8)
        Me.ribbonItemGroup2.Items.Add(Me.ribbonButton9)
        Me.ribbonItemGroup2.Name = "ribbonItemGroup2"
        Me.ribbonItemGroup2.Text = "ribbonItemGroup2"
        '
        'ribbonButton8
        '
        Me.ribbonButton8.Image = CType(resources.GetObject("ribbonButton8.Image"), Image)
        Me.ribbonButton8.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton8.Name = "ribbonButton8"
        Me.ribbonButton8.SmallImage = My.Resources.Resources.fontsizeincrease16
        Me.ribbonButton8.Text = "ribbonButton8"
        '
        'ribbonButton9
        '
        Me.ribbonButton9.Image = CType(resources.GetObject("ribbonButton9.Image"), Image)
        Me.ribbonButton9.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton9.Name = "ribbonButton9"
        Me.ribbonButton9.SmallImage = My.Resources.Resources.fontsizedecrease16
        Me.ribbonButton9.Text = "ribbonButton9"
        '
        'ribbonItemGroup3
        '
        Me.ribbonItemGroup3.Items.Add(Me.ribbonButton10)
        Me.ribbonItemGroup3.Name = "ribbonItemGroup3"
        Me.ribbonItemGroup3.Text = "ribbonItemGroup3"
        '
        'ribbonButton10
        '
        Me.ribbonButton10.Image = CType(resources.GetObject("ribbonButton10.Image"), Image)
        Me.ribbonButton10.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton10.Name = "ribbonButton10"
        Me.ribbonButton10.SmallImage = My.Resources.Resources.eraseformat16
        Me.ribbonButton10.Text = "ribbonButton10"
        '
        'ribbonItemGroup4
        '
        Me.ribbonItemGroup4.Items.Add(Me.ribbonButton11)
        Me.ribbonItemGroup4.Items.Add(Me.ribbonButton12)
        Me.ribbonItemGroup4.Items.Add(Me.ribbonButton13)
        Me.ribbonItemGroup4.Items.Add(Me.ribbonButton14)
        Me.ribbonItemGroup4.Items.Add(Me.ribbonButton15)
        Me.ribbonItemGroup4.Items.Add(Me.ribbonButton16)
        Me.ribbonItemGroup4.Items.Add(Me.ribbonButton17)
        Me.ribbonItemGroup4.Name = "ribbonItemGroup4"
        Me.ribbonItemGroup4.Text = "ribbonItemGroup4"
        '
        'ribbonButton11
        '
        Me.ribbonButton11.Image = CType(resources.GetObject("ribbonButton11.Image"), Image)
        Me.ribbonButton11.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton11.Name = "ribbonButton11"
        Me.ribbonButton11.SmallImage = My.Resources.Resources.bold16
        Me.ribbonButton11.Text = "ribbonButton11"
        '
        'ribbonButton12
        '
        Me.ribbonButton12.Image = CType(resources.GetObject("ribbonButton12.Image"), Image)
        Me.ribbonButton12.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton12.Name = "ribbonButton12"
        Me.ribbonButton12.SmallImage = My.Resources.Resources.italic16
        Me.ribbonButton12.Text = "ribbonButton12"
        '
        'ribbonButton13
        '
        Me.ribbonButton13.Image = CType(resources.GetObject("ribbonButton13.Image"), Image)
        Me.ribbonButton13.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton13.Name = "ribbonButton13"
        Me.ribbonButton13.SmallImage = My.Resources.Resources.underline16
        Me.ribbonButton13.Style = RibbonButtonStyle.SplitDropDown
        Me.ribbonButton13.Text = "ribbonButton13"
        '
        'ribbonButton14
        '
        Me.ribbonButton14.Image = CType(resources.GetObject("ribbonButton14.Image"), Image)
        Me.ribbonButton14.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton14.Name = "ribbonButton14"
        Me.ribbonButton14.SmallImage = My.Resources.Resources.strikethru16
        Me.ribbonButton14.Text = "ribbonButton14"
        '
        'ribbonButton15
        '
        Me.ribbonButton15.Image = CType(resources.GetObject("ribbonButton15.Image"), Image)
        Me.ribbonButton15.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton15.Name = "ribbonButton15"
        Me.ribbonButton15.SmallImage = My.Resources.Resources.subindex16
        Me.ribbonButton15.Text = "ribbonButton15"
        '
        'ribbonButton16
        '
        Me.ribbonButton16.Image = CType(resources.GetObject("ribbonButton16.Image"), Image)
        Me.ribbonButton16.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton16.Name = "ribbonButton16"
        Me.ribbonButton16.SmallImage = My.Resources.Resources.superindex16
        Me.ribbonButton16.Text = "ribbonButton16"
        '
        'ribbonButton17
        '
        Me.ribbonButton17.DropDownItems.Add(Me.ribbonButton18)
        Me.ribbonButton17.DropDownItems.Add(Me.ribbonButton19)
        Me.ribbonButton17.DropDownItems.Add(Me.ribbonButton20)
        Me.ribbonButton17.DropDownItems.Add(Me.ribbonButton21)
        Me.ribbonButton17.DropDownItems.Add(Me.ribbonButton22)
        Me.ribbonButton17.Image = CType(resources.GetObject("ribbonButton17.Image"), Image)
        Me.ribbonButton17.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton17.Name = "ribbonButton17"
        Me.ribbonButton17.SmallImage = My.Resources.Resources.casing16
        Me.ribbonButton17.Style = RibbonButtonStyle.DropDown
        Me.ribbonButton17.Text = "ribbonButton17"
        '
        'ribbonButton18
        '
        Me.ribbonButton18.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton18.Image = CType(resources.GetObject("ribbonButton18.Image"), Image)
        Me.ribbonButton18.Name = "ribbonButton18"
        Me.ribbonButton18.SmallImage = CType(resources.GetObject("ribbonButton18.SmallImage"), Image)
        Me.ribbonButton18.Text = "Sentence case."
        '
        'ribbonButton19
        '
        Me.ribbonButton19.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton19.Image = CType(resources.GetObject("ribbonButton19.Image"), Image)
        Me.ribbonButton19.Name = "ribbonButton19"
        Me.ribbonButton19.SmallImage = CType(resources.GetObject("ribbonButton19.SmallImage"), Image)
        Me.ribbonButton19.Text = "lowercase"
        '
        'ribbonButton20
        '
        Me.ribbonButton20.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton20.Image = CType(resources.GetObject("ribbonButton20.Image"), Image)
        Me.ribbonButton20.Name = "ribbonButton20"
        Me.ribbonButton20.SmallImage = CType(resources.GetObject("ribbonButton20.SmallImage"), Image)
        Me.ribbonButton20.Text = "UPPERCASE"
        '
        'ribbonButton21
        '
        Me.ribbonButton21.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton21.Image = CType(resources.GetObject("ribbonButton21.Image"), Image)
        Me.ribbonButton21.Name = "ribbonButton21"
        Me.ribbonButton21.SmallImage = CType(resources.GetObject("ribbonButton21.SmallImage"), Image)
        Me.ribbonButton21.Text = "Capitalize Each Word"
        '
        'ribbonButton22
        '
        Me.ribbonButton22.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton22.Image = CType(resources.GetObject("ribbonButton22.Image"), Image)
        Me.ribbonButton22.Name = "ribbonButton22"
        Me.ribbonButton22.SmallImage = CType(resources.GetObject("ribbonButton22.SmallImage"), Image)
        Me.ribbonButton22.Text = "tOGGLE cASE"
        '
        'ribbonItemGroup5
        '
        Me.ribbonItemGroup5.Items.Add(Me.ribbonColorChooser1)
        Me.ribbonItemGroup5.Items.Add(Me.ribbonColorChooser2)
        Me.ribbonItemGroup5.Name = "ribbonItemGroup5"
        Me.ribbonItemGroup5.Text = "ribbonItemGroup5"
        Me.ribbonItemGroup5.Visible = False
        '
        'ribbonColorChooser1
        '
        Me.ribbonColorChooser1.Color = Color.Yellow
        Me.ribbonColorChooser1.Image = CType(resources.GetObject("ribbonColorChooser1.Image"), Image)
        Me.ribbonColorChooser1.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonColorChooser1.Name = "ribbonColorChooser1"
        Me.ribbonColorChooser1.SmallImage = My.Resources.Resources.hilight16
        Me.ribbonColorChooser1.Style = RibbonButtonStyle.SplitDropDown
        Me.ribbonColorChooser1.Text = "ribbonColorChooser1"
        '
        'ribbonColorChooser2
        '
        Me.ribbonColorChooser2.Color = Color.Blue
        Me.ribbonColorChooser2.Image = CType(resources.GetObject("ribbonColorChooser2.Image"), Image)
        Me.ribbonColorChooser2.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonColorChooser2.Name = "ribbonColorChooser2"
        Me.ribbonColorChooser2.SmallImage = My.Resources.Resources.fontcolor16
        Me.ribbonColorChooser2.Style = RibbonButtonStyle.SplitDropDown
        Me.ribbonColorChooser2.Text = "ribbonColorChooser2"
        '
        'ribbonPanel3
        '
        Me.ribbonPanel3.FlowsTo = RibbonPanelFlowDirection.Right
        Me.ribbonPanel3.Image = My.Resources.Resources.textaligncenter16
        Me.ribbonPanel3.Items.Add(Me.ribbonItemGroup6)
        Me.ribbonPanel3.Items.Add(Me.ribbonItemGroup7)
        Me.ribbonPanel3.Items.Add(Me.ribbonItemGroup8)
        Me.ribbonPanel3.Items.Add(Me.ribbonItemGroup9)
        Me.ribbonPanel3.Items.Add(Me.ribbonItemGroup10)
        Me.ribbonPanel3.Items.Add(Me.ribbonItemGroup11)
        Me.ribbonPanel3.Items.Add(Me.ribbonItemGroup12)
        Me.ribbonPanel3.Name = "ribbonPanel3"
        Me.ribbonPanel3.Text = "Paragraph"
        Me.ribbonPanel3.Visible = False
        '
        'ribbonItemGroup6
        '
        Me.ribbonItemGroup6.Items.Add(Me.ribbonButton23)
        Me.ribbonItemGroup6.Items.Add(Me.ribbonButton24)
        Me.ribbonItemGroup6.Items.Add(Me.ribbonButton25)
        Me.ribbonItemGroup6.Name = "ribbonItemGroup6"
        Me.ribbonItemGroup6.Text = "ribbonItemGroup6"
        '
        'ribbonButton23
        '
        Me.ribbonButton23.Image = CType(resources.GetObject("ribbonButton23.Image"), Image)
        Me.ribbonButton23.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton23.Name = "ribbonButton23"
        Me.ribbonButton23.SmallImage = My.Resources.Resources.unorderedlist16
        Me.ribbonButton23.Style = RibbonButtonStyle.SplitDropDown
        Me.ribbonButton23.Text = "ribbonButton23"
        '
        'ribbonButton24
        '
        Me.ribbonButton24.Image = CType(resources.GetObject("ribbonButton24.Image"), Image)
        Me.ribbonButton24.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton24.Name = "ribbonButton24"
        Me.ribbonButton24.SmallImage = My.Resources.Resources.orderedlist16
        Me.ribbonButton24.Style = RibbonButtonStyle.SplitDropDown
        Me.ribbonButton24.Text = "ribbonButton24"
        '
        'ribbonButton25
        '
        Me.ribbonButton25.Image = CType(resources.GetObject("ribbonButton25.Image"), Image)
        Me.ribbonButton25.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton25.Name = "ribbonButton25"
        Me.ribbonButton25.SmallImage = My.Resources.Resources.multilevellist16
        Me.ribbonButton25.Style = RibbonButtonStyle.DropDown
        Me.ribbonButton25.Text = "ribbonButton25"
        '
        'ribbonItemGroup7
        '
        Me.ribbonItemGroup7.Items.Add(Me.ribbonButton26)
        Me.ribbonItemGroup7.Items.Add(Me.ribbonButton27)
        Me.ribbonItemGroup7.Name = "ribbonItemGroup7"
        Me.ribbonItemGroup7.Text = "ribbonItemGroup7"
        '
        'ribbonButton26
        '
        Me.ribbonButton26.Image = CType(resources.GetObject("ribbonButton26.Image"), Image)
        Me.ribbonButton26.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton26.Name = "ribbonButton26"
        Me.ribbonButton26.SmallImage = My.Resources.Resources.indentdecrease16
        Me.ribbonButton26.Text = "ribbonButton26"
        '
        'ribbonButton27
        '
        Me.ribbonButton27.Image = CType(resources.GetObject("ribbonButton27.Image"), Image)
        Me.ribbonButton27.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton27.Name = "ribbonButton27"
        Me.ribbonButton27.SmallImage = My.Resources.Resources.indentincrease16
        Me.ribbonButton27.Text = "ribbonButton27"
        '
        'ribbonItemGroup8
        '
        Me.ribbonItemGroup8.Items.Add(Me.ribbonButton29)
        Me.ribbonItemGroup8.Name = "ribbonItemGroup8"
        Me.ribbonItemGroup8.Text = "ribbonItemGroup8"
        '
        'ribbonButton29
        '
        Me.ribbonButton29.Image = CType(resources.GetObject("ribbonButton29.Image"), Image)
        Me.ribbonButton29.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton29.Name = "ribbonButton29"
        Me.ribbonButton29.SmallImage = My.Resources.Resources.invisiblechars16
        Me.ribbonButton29.Text = "ribbonButton29"
        '
        'ribbonItemGroup9
        '
        Me.ribbonItemGroup9.Items.Add(Me.ribbonButton28)
        Me.ribbonItemGroup9.Name = "ribbonItemGroup9"
        Me.ribbonItemGroup9.Text = "ribbonItemGroup9"
        '
        'ribbonButton28
        '
        Me.ribbonButton28.Image = CType(resources.GetObject("ribbonButton28.Image"), Image)
        Me.ribbonButton28.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton28.Name = "ribbonButton28"
        Me.ribbonButton28.SmallImage = My.Resources.Resources.sort16
        Me.ribbonButton28.Text = "ribbonButton28"
        '
        'ribbonItemGroup10
        '
        Me.ribbonItemGroup10.Items.Add(Me.ribbonColorChooser3)
        Me.ribbonItemGroup10.Items.Add(Me.ribbonButton31)
        Me.ribbonItemGroup10.Name = "ribbonItemGroup10"
        Me.ribbonItemGroup10.Text = "ribbonItemGroup10"
        '
        'ribbonColorChooser3
        '
        Me.ribbonColorChooser3.Color = Color.Transparent
        Me.ribbonColorChooser3.Image = CType(resources.GetObject("ribbonColorChooser3.Image"), Image)
        Me.ribbonColorChooser3.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonColorChooser3.Name = "ribbonColorChooser3"
        Me.ribbonColorChooser3.SmallImage = My.Resources.Resources.fill16
        Me.ribbonColorChooser3.Style = RibbonButtonStyle.SplitDropDown
        Me.ribbonColorChooser3.Text = "ribbonColorChooser3"
        '
        'ribbonButton31
        '
        Me.ribbonButton31.Image = CType(resources.GetObject("ribbonButton31.Image"), Image)
        Me.ribbonButton31.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton31.Name = "ribbonButton31"
        Me.ribbonButton31.SmallImage = My.Resources.Resources.borderbottom16
        Me.ribbonButton31.Style = RibbonButtonStyle.SplitDropDown
        Me.ribbonButton31.Text = "ribbonButton31"
        '
        'ribbonItemGroup11
        '
        Me.ribbonItemGroup11.Items.Add(Me.ribbonButton30)
        Me.ribbonItemGroup11.Name = "ribbonItemGroup11"
        Me.ribbonItemGroup11.Text = "ribbonItemGroup11"
        '
        'ribbonButton30
        '
        Me.ribbonButton30.Image = CType(resources.GetObject("ribbonButton30.Image"), Image)
        Me.ribbonButton30.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton30.Name = "ribbonButton30"
        Me.ribbonButton30.SmallImage = My.Resources.Resources.paragraphspacing16
        Me.ribbonButton30.Text = "ribbonButton30"
        '
        'ribbonItemGroup12
        '
        Me.ribbonItemGroup12.Items.Add(Me.ribbonButton32)
        Me.ribbonItemGroup12.Items.Add(Me.ribbonButton33)
        Me.ribbonItemGroup12.Items.Add(Me.ribbonButton34)
        Me.ribbonItemGroup12.Items.Add(Me.ribbonButton35)
        Me.ribbonItemGroup12.Name = "ribbonItemGroup12"
        Me.ribbonItemGroup12.Text = "ribbonItemGroup12"
        '
        'ribbonButton32
        '
        Me.ribbonButton32.Image = CType(resources.GetObject("ribbonButton32.Image"), Image)
        Me.ribbonButton32.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton32.Name = "ribbonButton32"
        Me.ribbonButton32.SmallImage = My.Resources.Resources.textalignleft16
        Me.ribbonButton32.Text = "ribbonButton32"
        '
        'ribbonButton33
        '
        Me.ribbonButton33.Image = CType(resources.GetObject("ribbonButton33.Image"), Image)
        Me.ribbonButton33.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton33.Name = "ribbonButton33"
        Me.ribbonButton33.SmallImage = My.Resources.Resources.textaligncenter16
        Me.ribbonButton33.Text = "ribbonButton33"
        '
        'ribbonButton34
        '
        Me.ribbonButton34.Image = CType(resources.GetObject("ribbonButton34.Image"), Image)
        Me.ribbonButton34.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton34.Name = "ribbonButton34"
        Me.ribbonButton34.SmallImage = My.Resources.Resources.textalignright16
        Me.ribbonButton34.Text = "ribbonButton34"
        '
        'ribbonButton35
        '
        Me.ribbonButton35.Image = CType(resources.GetObject("ribbonButton35.Image"), Image)
        Me.ribbonButton35.MaxSizeMode = RibbonElementSizeMode.Compact
        Me.ribbonButton35.Name = "ribbonButton35"
        Me.ribbonButton35.SmallImage = My.Resources.Resources.textalignjustify16
        Me.ribbonButton35.Text = "ribbonButton35"
        '
        'ribbonPanel4
        '
        Me.ribbonPanel4.Image = CType(resources.GetObject("ribbonPanel4.Image"), Image)
        Me.ribbonPanel4.Items.Add(Me.lst)
        Me.ribbonPanel4.Items.Add(Me.ribbonButton36)
        Me.ribbonPanel4.Name = "ribbonPanel4"
        Me.ribbonPanel4.Text = "Styles"
        '
        'lst
        '
        Me.lst.ButtonsSizeMode = RibbonElementSizeMode.Large
        Me.lst.FlowToBottom = False
        Me.lst.ItemsSizeInDropwDownMode = New Size(7, 5)
        Me.lst.Name = "lst"
        Me.lst.Text = "ribbonButtonList1"
        '
        'ribbonButton36
        '
        Me.ribbonButton36.DropDownItems.Add(Me.ribbonButton37)
        Me.ribbonButton36.DropDownItems.Add(Me.itemColors)
        Me.ribbonButton36.DropDownItems.Add(Me.ribbonButton39)
        Me.ribbonButton36.DropDownItems.Add(Me.ribbonSeparator1)
        Me.ribbonButton36.DropDownItems.Add(Me.ribbonButton40)
        Me.ribbonButton36.Image = My.Resources.Resources.stylechange32
        Me.ribbonButton36.MinSizeMode = RibbonElementSizeMode.Large
        Me.ribbonButton36.Name = "ribbonButton36"
        Me.ribbonButton36.SmallImage = CType(resources.GetObject("ribbonButton36.SmallImage"), Image)
        Me.ribbonButton36.Style = RibbonButtonStyle.DropDown
        Me.ribbonButton36.Text = "Change Styles"
        '
        'ribbonButton37
        '
        Me.ribbonButton37.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton37.Image = CType(resources.GetObject("ribbonButton37.Image"), Image)
        Me.ribbonButton37.Name = "ribbonButton37"
        Me.ribbonButton37.SmallImage = My.Resources.Resources.styleset16
        Me.ribbonButton37.Text = "Style set"
        '
        'itemColors
        '
        Me.itemColors.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.itemColors.DropDownItems.Add(Me.ribbonButton38)
        Me.itemColors.DropDownItems.Add(Me.ribbonSeparator2)
        Me.itemColors.DropDownItems.Add(Me.ribbonButton41)
        Me.itemColors.Image = CType(resources.GetObject("itemColors.Image"), Image)
        Me.itemColors.Name = "itemColors"
        Me.itemColors.SmallImage = CType(resources.GetObject("itemColors.SmallImage"), Image)
        Me.itemColors.Style = RibbonButtonStyle.DropDown
        Me.itemColors.Text = "Colors"
        '
        'ribbonButton38
        '
        Me.ribbonButton38.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton38.Image = CType(resources.GetObject("ribbonButton38.Image"), Image)
        Me.ribbonButton38.Name = "ribbonButton38"
        Me.ribbonButton38.SmallImage = CType(resources.GetObject("ribbonButton38.SmallImage"), Image)
        Me.ribbonButton38.Text = "Create new theme colors..."
        '
        'ribbonSeparator2
        '
        Me.ribbonSeparator2.Name = "ribbonSeparator2"
        '
        'ribbonButton41
        '
        Me.ribbonButton41.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton41.Image = CType(resources.GetObject("ribbonButton41.Image"), Image)
        Me.ribbonButton41.Name = "ribbonButton41"
        Me.ribbonButton41.SmallImage = CType(resources.GetObject("ribbonButton41.SmallImage"), Image)
        Me.ribbonButton41.Text = "Some other option"
        '
        'ribbonButton39
        '
        Me.ribbonButton39.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton39.Image = CType(resources.GetObject("ribbonButton39.Image"), Image)
        Me.ribbonButton39.Name = "ribbonButton39"
        Me.ribbonButton39.SmallImage = My.Resources.Resources.themefont
        Me.ribbonButton39.Text = "Fonts"
        '
        'ribbonSeparator1
        '
        Me.ribbonSeparator1.Name = "ribbonSeparator1"
        '
        'ribbonButton40
        '
        Me.ribbonButton40.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton40.Image = CType(resources.GetObject("ribbonButton40.Image"), Image)
        Me.ribbonButton40.Name = "ribbonButton40"
        Me.ribbonButton40.SmallImage = CType(resources.GetObject("ribbonButton40.SmallImage"), Image)
        Me.ribbonButton40.Text = "Set as default value"
        '
        'ribbonPanel5
        '
        Me.ribbonPanel5.Items.Add(Me.ribbonButton46)
        Me.ribbonPanel5.Items.Add(Me.ribbonButton47)
        Me.ribbonPanel5.Items.Add(Me.ribbonButton48)
        Me.ribbonPanel5.Items.Add(Me.ribbonButton49)
        Me.ribbonPanel5.Name = "ribbonPanel5"
        Me.ribbonPanel5.Text = "Editing"
        '
        'ribbonButton46
        '
        Me.ribbonButton46.Image = My.Resources.Resources.find32
        Me.ribbonButton46.MinSizeMode = RibbonElementSizeMode.Large
        Me.ribbonButton46.Name = "ribbonButton46"
        Me.ribbonButton46.SmallImage = CType(resources.GetObject("ribbonButton46.SmallImage"), Image)
        Me.ribbonButton46.Text = "Find"
        Me.ribbonButton46.ToolTip = "Find"
        '
        'ribbonButton47
        '
        Me.ribbonButton47.Image = CType(resources.GetObject("ribbonButton47.Image"), Image)
        Me.ribbonButton47.MaxSizeMode = RibbonElementSizeMode.Medium
        Me.ribbonButton47.Name = "ribbonButton47"
        Me.ribbonButton47.SmallImage = My.Resources.Resources.replace16
        Me.ribbonButton47.Text = "Replace"
        '
        'ribbonButton48
        '
        Me.ribbonButton48.Image = CType(resources.GetObject("ribbonButton48.Image"), Image)
        Me.ribbonButton48.MaxSizeMode = RibbonElementSizeMode.Medium
        Me.ribbonButton48.Name = "ribbonButton48"
        Me.ribbonButton48.SmallImage = My.Resources.Resources.goto16
        Me.ribbonButton48.Text = "Go To"
        '
        'ribbonButton49
        '
        Me.ribbonButton49.DropDownItems.Add(Me.ribbonButton50)
        Me.ribbonButton49.DropDownItems.Add(Me.ribbonButton51)
        Me.ribbonButton49.DropDownItems.Add(Me.ribbonButton52)
        Me.ribbonButton49.Image = CType(resources.GetObject("ribbonButton49.Image"), Image)
        Me.ribbonButton49.MaxSizeMode = RibbonElementSizeMode.Medium
        Me.ribbonButton49.Name = "ribbonButton49"
        Me.ribbonButton49.SmallImage = My.Resources.Resources.select16
        Me.ribbonButton49.Style = RibbonButtonStyle.DropDown
        Me.ribbonButton49.Text = "Select"
        '
        'ribbonButton50
        '
        Me.ribbonButton50.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton50.Image = CType(resources.GetObject("ribbonButton50.Image"), Image)
        Me.ribbonButton50.Name = "ribbonButton50"
        Me.ribbonButton50.SmallImage = My.Resources.Resources.pageblank16
        Me.ribbonButton50.Text = "Select everything"
        '
        'ribbonButton51
        '
        Me.ribbonButton51.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton51.Image = CType(resources.GetObject("ribbonButton51.Image"), Image)
        Me.ribbonButton51.Name = "ribbonButton51"
        Me.ribbonButton51.SmallImage = My.Resources.Resources.select16
        Me.ribbonButton51.Text = "Select Text"
        '
        'ribbonButton52
        '
        Me.ribbonButton52.DropDownArrowDirection = RibbonArrowDirection.Left
        Me.ribbonButton52.Image = CType(resources.GetObject("ribbonButton52.Image"), Image)
        Me.ribbonButton52.Name = "ribbonButton52"
        Me.ribbonButton52.SmallImage = CType(resources.GetObject("ribbonButton52.SmallImage"), Image)
        Me.ribbonButton52.Text = "Select text with similar format"
        '
        'panelMain
        '
        Me.panelMain.BackColor = Color.Peru
        Me.panelMain.Controls.Add(Me.label4)
        Me.panelMain.Controls.Add(Me.label3)
        Me.panelMain.Controls.Add(Me.label2)
        Me.panelMain.Controls.Add(Me.label1)
        Me.panelMain.Dock = DockStyle.Fill
        Me.panelMain.Location = New Point(0, 138)
        Me.panelMain.Name = "panelMain"
        Me.panelMain.Size = New Size(928, 126)
        Me.panelMain.TabIndex = 1
        '
        'label4
        '
        Me.label4.AutoSize = True
        Me.label4.Dock = DockStyle.Right
        Me.label4.Font = New Font("Microsoft Sans Serif", 9.75!, FontStyle.Bold, GraphicsUnit.Point, CType(0, Byte))
        Me.label4.Location = New Point(824, 16)
        Me.label4.Name = "label4"
        Me.label4.Size = New Size(104, 16)
        Me.label4.TabIndex = 3
        Me.label4.Text = "Dock - RIGHT"
        '
        'label3
        '
        Me.label3.AutoSize = True
        Me.label3.Dock = DockStyle.Bottom
        Me.label3.Font = New Font("Microsoft Sans Serif", 9.75!, FontStyle.Bold, GraphicsUnit.Point, CType(0, Byte))
        Me.label3.Location = New Point(94, 110)
        Me.label3.Name = "label3"
        Me.label3.Size = New Size(121, 16)
        Me.label3.TabIndex = 2
        Me.label3.Text = "Dock - BOTTOM"
        '
        'label2
        '
        Me.label2.AutoSize = True
        Me.label2.Dock = DockStyle.Left
        Me.label2.Font = New Font("Microsoft Sans Serif", 9.75!, FontStyle.Bold, GraphicsUnit.Point, CType(0, Byte))
        Me.label2.Location = New Point(0, 16)
        Me.label2.Name = "label2"
        Me.label2.Size = New Size(94, 16)
        Me.label2.TabIndex = 1
        Me.label2.Text = "Dock - LEFT"
        '
        'label1
        '
        Me.label1.AutoSize = True
        Me.label1.Dock = DockStyle.Top
        Me.label1.Font = New Font("Microsoft Sans Serif", 9.75!, FontStyle.Bold, GraphicsUnit.Point, CType(0, Byte))
        Me.label1.Location = New Point(0, 0)
        Me.label1.Name = "label1"
        Me.label1.Size = New Size(88, 16)
        Me.label1.TabIndex = 0
        Me.label1.Text = "Dock - TOP"
        '
        'Form1
        '
        Me.ClientSize = New Size(928, 264)
        Me.Controls.Add(Me.panelMain)
        Me.Controls.Add(Me.ribbon1)
        Me.KeyPreview = True
        Me.Name = "Form1"
        Me.Text = "Ribbon Demo Form"
        Me.panelMain.ResumeLayout(False)
        Me.panelMain.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        Me.InitLists()

    End Sub

    Private WithEvents ribbonTab1 As RibbonTab

    Private WithEvents ribbonPanel1 As RibbonPanel

    Private WithEvents ribbonButton1 As RibbonButton

    Protected WithEvents ribbon1 As Ribbon

    Private WithEvents ribbonButton2 As RibbonButton

    Private WithEvents ribbonButton3 As RibbonButton

    Private WithEvents ribbonButton4 As RibbonButton

    Private WithEvents ribbonButton5 As RibbonButton

    Private WithEvents ribbonButton6 As RibbonButton

    Private WithEvents ribbonButton7 As RibbonButton

    Private WithEvents ribbonPanel2 As RibbonPanel

    Private WithEvents ribbonItemGroup1 As RibbonItemGroup

    Private WithEvents ribbonComboBox1 As RibbonComboBox

    Private WithEvents ribbonComboBox2 As RibbonComboBox

    Private WithEvents ribbonItemGroup2 As RibbonItemGroup

    Private WithEvents ribbonButton8 As RibbonButton

    Private WithEvents ribbonButton9 As RibbonButton

    Private WithEvents ribbonItemGroup3 As RibbonItemGroup

    Private WithEvents ribbonButton10 As RibbonButton

    Private WithEvents ribbonItemGroup4 As RibbonItemGroup

    Private WithEvents ribbonButton11 As RibbonButton

    Private WithEvents ribbonButton12 As RibbonButton

    Private WithEvents ribbonButton13 As RibbonButton

    Private WithEvents ribbonButton14 As RibbonButton

    Private WithEvents ribbonButton15 As RibbonButton

    Private WithEvents ribbonButton16 As RibbonButton

    Private WithEvents ribbonButton17 As RibbonButton

    Private WithEvents ribbonButton18 As RibbonButton

    Private WithEvents ribbonButton19 As RibbonButton

    Private WithEvents ribbonButton20 As RibbonButton

    Private WithEvents ribbonButton21 As RibbonButton

    Private WithEvents ribbonButton22 As RibbonButton

    Private WithEvents ribbonPanel3 As RibbonPanel

    Private WithEvents ribbonItemGroup5 As RibbonItemGroup

    Private WithEvents ribbonColorChooser1 As RibbonColorChooser

    Private WithEvents ribbonColorChooser2 As RibbonColorChooser

    Private WithEvents ribbonItemGroup6 As RibbonItemGroup

    Private WithEvents ribbonButton23 As RibbonButton

    Private WithEvents ribbonButton24 As RibbonButton

    Private WithEvents ribbonButton25 As RibbonButton

    Private WithEvents ribbonItemGroup7 As RibbonItemGroup

    Private WithEvents ribbonItemGroup8 As RibbonItemGroup

    Private WithEvents ribbonItemGroup9 As RibbonItemGroup

    Private WithEvents ribbonItemGroup10 As RibbonItemGroup

    Private WithEvents ribbonItemGroup11 As RibbonItemGroup

    Private WithEvents ribbonButton26 As RibbonButton

    Private WithEvents ribbonButton27 As RibbonButton

    Private WithEvents ribbonButton28 As RibbonButton

    Private WithEvents ribbonButton29 As RibbonButton

    Private WithEvents ribbonButton30 As RibbonButton

    Private WithEvents ribbonColorChooser3 As RibbonColorChooser

    Private WithEvents ribbonButton31 As RibbonButton

    Private WithEvents ribbonItemGroup12 As RibbonItemGroup

    Private WithEvents ribbonButton32 As RibbonButton

    Private WithEvents ribbonButton33 As RibbonButton

    Private WithEvents ribbonButton34 As RibbonButton

    Private WithEvents ribbonButton35 As RibbonButton

    Private WithEvents ribbonPanel4 As RibbonPanel

    Private WithEvents lst As RibbonButtonList

    Private WithEvents ribbonButton36 As RibbonButton

    Private WithEvents ribbonButton37 As RibbonButton

    Private WithEvents itemColors As RibbonButton

    Private WithEvents ribbonButton39 As RibbonButton

    Private WithEvents ribbonSeparator1 As RibbonSeparator

    Private WithEvents ribbonButton40 As RibbonButton

    Private WithEvents ribbonButton38 As RibbonButton

    Private WithEvents ribbonSeparator2 As RibbonSeparator

    Private WithEvents ribbonButton41 As RibbonButton

    Private WithEvents ribbonButton42 As RibbonButton

    Private WithEvents ribbonButton43 As RibbonButton

    Private WithEvents ribbonButton44 As RibbonButton

    Private WithEvents ribbonButton45 As RibbonButton

    Private WithEvents ribbonOrbMenuItem1 As RibbonOrbMenuItem

    Private WithEvents ribbonOrbMenuItem2 As RibbonOrbMenuItem

    Private WithEvents ribbonOrbMenuItem3 As RibbonOrbMenuItem

    Private WithEvents ribbonOrbMenuItem4 As RibbonOrbMenuItem

    Private WithEvents ribbonSeparator3 As RibbonSeparator

    Private WithEvents ribbonOrbMenuItem5 As RibbonOrbMenuItem

    Private WithEvents ribbonOrbMenuItem6 As RibbonOrbMenuItem

    Private WithEvents ribbonOrbMenuItem7 As RibbonOrbMenuItem

    Private WithEvents ribbonOrbMenuItem8 As RibbonOrbMenuItem

    Private WithEvents ribbonSeparator4 As RibbonSeparator

    Private WithEvents ribbonOrbMenuItem9 As RibbonOrbMenuItem

    Private WithEvents ribbonDescriptionMenuItem1 As RibbonDescriptionMenuItem

    Private WithEvents ribbonDescriptionMenuItem2 As RibbonDescriptionMenuItem

    Private WithEvents ribbonDescriptionMenuItem3 As RibbonDescriptionMenuItem

    Private WithEvents ribbonDescriptionMenuItem4 As RibbonDescriptionMenuItem

    Private WithEvents ribbonDescriptionMenuItem5 As RibbonDescriptionMenuItem

    Private WithEvents ribbonSeparator5 As RibbonSeparator

    Private WithEvents ribbonDescriptionMenuItem6 As RibbonDescriptionMenuItem

    Private WithEvents ribbonDescriptionMenuItem7 As RibbonDescriptionMenuItem

    Private WithEvents ribbonDescriptionMenuItem8 As RibbonDescriptionMenuItem

    Private WithEvents ribbonSeparator6 As RibbonSeparator

    Private WithEvents ribbonOrbOptionButton1 As RibbonOrbOptionButton

    Private WithEvents ribbonOrbOptionButton2 As RibbonOrbOptionButton

    Private WithEvents ribbonOrbRecentItem1 As RibbonOrbRecentItem

    Private WithEvents ribbonOrbRecentItem2 As RibbonOrbRecentItem

    Private WithEvents ribbonOrbRecentItem3 As RibbonOrbRecentItem

    Private WithEvents ribbonPanel5 As RibbonPanel

    Private WithEvents ribbonButton46 As RibbonButton

    Private WithEvents ribbonButton47 As RibbonButton

    Private WithEvents ribbonButton48 As RibbonButton

    Private WithEvents ribbonButton49 As RibbonButton

    Private WithEvents ribbonButton50 As RibbonButton

    Private WithEvents ribbonButton51 As RibbonButton

    Private WithEvents ribbonButton52 As RibbonButton

    Private WithEvents ribbonSeparator7 As RibbonSeparator

    Private WithEvents panelMain As Panel

    Private WithEvents label4 As Label

    Private WithEvents label3 As Label

    Private WithEvents label2 As Label

    Private WithEvents label1 As Label









End Class
