﻿using System.Windows.Forms;

namespace RibbonDemo2
{
    public partial class frmForm2 : Form
    {
        public frmForm2()
        {
            InitializeComponent();
        }
    }
}