# WinFormsMDI2
nuget: [![NuGet version (SoftCircuits.Silk)](https://img.shields.io/nuget/v/WinFormsMDI2.svg?style=flat-square)](https://www.nuget.org/packages/WinFormsMDI2/)

It is already known that microsoft has basically discontinued the MDI system. it's been more than 8 years since she stopped updating it... This project aims to bring a new efficient/free/opensoure/customizable MDI system to replace the old system

(version 1.0 images)

![image1](https://user-images.githubusercontent.com/66432268/136716973-efeaad53-9fe1-44da-9993-affb050e0ea8.png)
![image2](https://user-images.githubusercontent.com/66432268/136717071-5d9603de-9f9c-434e-89ca-4350f0a79306.png)
![image3](https://user-images.githubusercontent.com/66432268/136717075-a4a70f67-9d4d-4834-83ff-99a0ac395316.png)
![image4](https://user-images.githubusercontent.com/66432268/136717078-6eb55b63-8cdf-46ba-af07-058eb50ad8fb.png)
