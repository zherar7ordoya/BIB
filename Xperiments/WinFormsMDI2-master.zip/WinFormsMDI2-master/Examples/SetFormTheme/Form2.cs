﻿namespace SetFormTheme;
public partial class Form2 : Form
{
    public Form2()
    {
        InitializeComponent();
    }
}
