﻿namespace FormUtilits.Themes;
public interface IFormTheme
{
    void SetMode(object? sender, FormThemeLoopArgs e);
}
