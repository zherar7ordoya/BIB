﻿namespace WinFormsMDI2_Test;
public partial class MdiCustom : WinFormsMDI2.MdiWin
{
    public MdiCustom()
    {
        InitializeComponent();
    }
}
