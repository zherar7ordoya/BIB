﻿using System.Windows.Forms;

namespace WinFormsMDI2_Test;

public partial class FormForMDI : Form
{
    public FormForMDI()
    {
        InitializeComponent();
    }
}
