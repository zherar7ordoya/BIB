﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Examen.BE
{
	public abstract class Componente
	{
		//metodos
		public int Size { get; set; }
	}
}
