﻿namespace Examen.BE
{
	public class Archivo : Componente
	{

	}
}