﻿namespace Examen.DAL
{
	public class Conection
	{

	}
}