﻿    using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BEherramientas
    {
        public string Nombre { get; set; }
        public string Color { get; set; }
        public string Origen { get; set; }
        public int Codigo { get; set; }
        public int Id { get; set; }
        public int Precio { get; set; }
        public int Estado { get; set; }
        public string Disponible { get; set; }
        public DateTime UltimaModificacion { get; set; }

    }
}
