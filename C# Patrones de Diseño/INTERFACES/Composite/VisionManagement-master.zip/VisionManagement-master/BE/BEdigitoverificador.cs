﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BEdigitoverificador
    {
        public int Peso { get; set; }
        public int Longitud { get; set; }
    }
}
