﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BEtabla
    {
        public int idDVV { get; set; }
        public int DVV { get; set; }
    }
}
