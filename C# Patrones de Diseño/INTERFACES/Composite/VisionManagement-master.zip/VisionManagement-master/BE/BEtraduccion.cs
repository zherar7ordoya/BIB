﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BE
{
    public class BEtraduccion
    {
        public int IdTraduccion { get; set; }
        public int IdCadena { get; set; }
        public int IdIdioma { get; set; }
        public string Cadena { get; set; }
    }
}
