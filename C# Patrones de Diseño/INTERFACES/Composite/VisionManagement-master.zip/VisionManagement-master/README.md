Hola a todos, este es mi primer gran proyecto para la materia trabajo de diploma. Es un programa que gestiona una ferreteria en el cual se pueden dar de alta clientes, articulos, herramientas para su
posterior venta en el caso de los articulos, y efectuar prestamos para las herramientas. El sistema cuanta con un modulo de seguridad donde las tablas de negocio estan afectadas por el DV.
Se puede realizar backup y restore de la bd. Ante un error de integridad el administrador puede arreglar los digitos o levantar el restore.
Se dan de alta usuarios del sistema, con sus respectivos permisos. Se pueden crear tantas familias y permisos como lo requiera el negocio.
Se utilizo el patron singleton para la sesion de usuario, y el composite para u-f-p.
