﻿namespace VisionTFI
{
    partial class ABMcliente
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_nombre = new System.Windows.Forms.Label();
            this.txt_nombre = new System.Windows.Forms.TextBox();
            this.txt_apellido = new System.Windows.Forms.TextBox();
            this.lbl_apellido = new System.Windows.Forms.Label();
            this.txt_cuit = new System.Windows.Forms.TextBox();
            this.lbl_cuit = new System.Windows.Forms.Label();
            this.txt_mail = new System.Windows.Forms.TextBox();
            this.lbl_mail = new System.Windows.Forms.Label();
            this.txt_direccion = new System.Windows.Forms.TextBox();
            this.lbl_direccion = new System.Windows.Forms.Label();
            this.txt_localidad = new System.Windows.Forms.TextBox();
            this.lbl_localidad = new System.Windows.Forms.Label();
            this.txt_telefono = new System.Windows.Forms.TextBox();
            this.lbl_telefono = new System.Windows.Forms.Label();
            this.btn_salir = new System.Windows.Forms.Button();
            this.btn_guardar = new System.Windows.Forms.Button();
            this.lbl_situacion = new System.Windows.Forms.Label();
            this.cmb_situacion = new System.Windows.Forms.ComboBox();
            this.lbl_tipoproceso = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl_nombre
            // 
            this.lbl_nombre.AutoSize = true;
            this.lbl_nombre.Location = new System.Drawing.Point(15, 183);
            this.lbl_nombre.Name = "lbl_nombre";
            this.lbl_nombre.Size = new System.Drawing.Size(50, 13);
            this.lbl_nombre.TabIndex = 26;
            this.lbl_nombre.Text = "Nombre :";
            // 
            // txt_nombre
            // 
            this.txt_nombre.Location = new System.Drawing.Point(71, 180);
            this.txt_nombre.Name = "txt_nombre";
            this.txt_nombre.Size = new System.Drawing.Size(250, 20);
            this.txt_nombre.TabIndex = 27;
            // 
            // txt_apellido
            // 
            this.txt_apellido.Location = new System.Drawing.Point(511, 180);
            this.txt_apellido.Name = "txt_apellido";
            this.txt_apellido.Size = new System.Drawing.Size(250, 20);
            this.txt_apellido.TabIndex = 29;
            // 
            // lbl_apellido
            // 
            this.lbl_apellido.AutoSize = true;
            this.lbl_apellido.Location = new System.Drawing.Point(455, 183);
            this.lbl_apellido.Name = "lbl_apellido";
            this.lbl_apellido.Size = new System.Drawing.Size(50, 13);
            this.lbl_apellido.TabIndex = 28;
            this.lbl_apellido.Text = "Apellido :";
            // 
            // txt_cuit
            // 
            this.txt_cuit.Location = new System.Drawing.Point(71, 245);
            this.txt_cuit.Name = "txt_cuit";
            this.txt_cuit.Size = new System.Drawing.Size(250, 20);
            this.txt_cuit.TabIndex = 31;
            // 
            // lbl_cuit
            // 
            this.lbl_cuit.AutoSize = true;
            this.lbl_cuit.Location = new System.Drawing.Point(15, 248);
            this.lbl_cuit.Name = "lbl_cuit";
            this.lbl_cuit.Size = new System.Drawing.Size(53, 13);
            this.lbl_cuit.TabIndex = 30;
            this.lbl_cuit.Text = "N° CUIT :";
            // 
            // txt_mail
            // 
            this.txt_mail.Location = new System.Drawing.Point(511, 245);
            this.txt_mail.Name = "txt_mail";
            this.txt_mail.Size = new System.Drawing.Size(250, 20);
            this.txt_mail.TabIndex = 33;
            // 
            // lbl_mail
            // 
            this.lbl_mail.AutoSize = true;
            this.lbl_mail.Location = new System.Drawing.Point(455, 248);
            this.lbl_mail.Name = "lbl_mail";
            this.lbl_mail.Size = new System.Drawing.Size(32, 13);
            this.lbl_mail.TabIndex = 32;
            this.lbl_mail.Text = "Mail :";
            // 
            // txt_direccion
            // 
            this.txt_direccion.Location = new System.Drawing.Point(71, 310);
            this.txt_direccion.Name = "txt_direccion";
            this.txt_direccion.Size = new System.Drawing.Size(250, 20);
            this.txt_direccion.TabIndex = 35;
            // 
            // lbl_direccion
            // 
            this.lbl_direccion.AutoSize = true;
            this.lbl_direccion.Location = new System.Drawing.Point(15, 313);
            this.lbl_direccion.Name = "lbl_direccion";
            this.lbl_direccion.Size = new System.Drawing.Size(58, 13);
            this.lbl_direccion.TabIndex = 34;
            this.lbl_direccion.Text = "Dirección :";
            // 
            // txt_localidad
            // 
            this.txt_localidad.Location = new System.Drawing.Point(511, 310);
            this.txt_localidad.Name = "txt_localidad";
            this.txt_localidad.Size = new System.Drawing.Size(250, 20);
            this.txt_localidad.TabIndex = 37;
            // 
            // lbl_localidad
            // 
            this.lbl_localidad.AutoSize = true;
            this.lbl_localidad.Location = new System.Drawing.Point(455, 313);
            this.lbl_localidad.Name = "lbl_localidad";
            this.lbl_localidad.Size = new System.Drawing.Size(59, 13);
            this.lbl_localidad.TabIndex = 36;
            this.lbl_localidad.Text = "Localidad :";
            // 
            // txt_telefono
            // 
            this.txt_telefono.Location = new System.Drawing.Point(71, 381);
            this.txt_telefono.Name = "txt_telefono";
            this.txt_telefono.Size = new System.Drawing.Size(250, 20);
            this.txt_telefono.TabIndex = 39;
            // 
            // lbl_telefono
            // 
            this.lbl_telefono.AutoSize = true;
            this.lbl_telefono.Location = new System.Drawing.Point(15, 384);
            this.lbl_telefono.Name = "lbl_telefono";
            this.lbl_telefono.Size = new System.Drawing.Size(55, 13);
            this.lbl_telefono.TabIndex = 38;
            this.lbl_telefono.Text = "Teléfono :";
            // 
            // btn_salir
            // 
            this.btn_salir.Location = new System.Drawing.Point(911, 434);
            this.btn_salir.Name = "btn_salir";
            this.btn_salir.Size = new System.Drawing.Size(119, 40);
            this.btn_salir.TabIndex = 40;
            this.btn_salir.Text = "Salir";
            this.btn_salir.UseVisualStyleBackColor = true;
            this.btn_salir.Click += new System.EventHandler(this.btn_salir_Click);
            // 
            // btn_guardar
            // 
            this.btn_guardar.Location = new System.Drawing.Point(767, 434);
            this.btn_guardar.Name = "btn_guardar";
            this.btn_guardar.Size = new System.Drawing.Size(119, 40);
            this.btn_guardar.TabIndex = 41;
            this.btn_guardar.Text = "Guardar";
            this.btn_guardar.UseVisualStyleBackColor = true;
            this.btn_guardar.Click += new System.EventHandler(this.btn_guardar_Click);
            // 
            // lbl_situacion
            // 
            this.lbl_situacion.AutoSize = true;
            this.lbl_situacion.Location = new System.Drawing.Point(455, 367);
            this.lbl_situacion.Name = "lbl_situacion";
            this.lbl_situacion.Size = new System.Drawing.Size(57, 13);
            this.lbl_situacion.TabIndex = 42;
            this.lbl_situacion.Text = "Situacion :";
            // 
            // cmb_situacion
            // 
            this.cmb_situacion.FormattingEnabled = true;
            this.cmb_situacion.Location = new System.Drawing.Point(511, 364);
            this.cmb_situacion.Name = "cmb_situacion";
            this.cmb_situacion.Size = new System.Drawing.Size(250, 21);
            this.cmb_situacion.TabIndex = 43;
            // 
            // lbl_tipoproceso
            // 
            this.lbl_tipoproceso.AutoSize = true;
            this.lbl_tipoproceso.Font = new System.Drawing.Font("Microsoft Sans Serif", 30F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_tipoproceso.ForeColor = System.Drawing.SystemColors.HotTrack;
            this.lbl_tipoproceso.Location = new System.Drawing.Point(579, 37);
            this.lbl_tipoproceso.Name = "lbl_tipoproceso";
            this.lbl_tipoproceso.Size = new System.Drawing.Size(207, 46);
            this.lbl_tipoproceso.TabIndex = 44;
            this.lbl_tipoproceso.Text = "                 ";
            // 
            // ABMcliente
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1168, 576);
            this.Controls.Add(this.lbl_tipoproceso);
            this.Controls.Add(this.cmb_situacion);
            this.Controls.Add(this.lbl_situacion);
            this.Controls.Add(this.btn_guardar);
            this.Controls.Add(this.btn_salir);
            this.Controls.Add(this.txt_telefono);
            this.Controls.Add(this.lbl_telefono);
            this.Controls.Add(this.txt_localidad);
            this.Controls.Add(this.lbl_localidad);
            this.Controls.Add(this.txt_direccion);
            this.Controls.Add(this.lbl_direccion);
            this.Controls.Add(this.txt_mail);
            this.Controls.Add(this.lbl_mail);
            this.Controls.Add(this.txt_cuit);
            this.Controls.Add(this.lbl_cuit);
            this.Controls.Add(this.txt_apellido);
            this.Controls.Add(this.lbl_apellido);
            this.Controls.Add(this.txt_nombre);
            this.Controls.Add(this.lbl_nombre);
            this.Name = "ABMcliente";
            this.Text = "Vision Management/ ABM clientes";
            this.Load += new System.EventHandler(this.ABMcliente_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lbl_nombre;
        private System.Windows.Forms.TextBox txt_nombre;
        private System.Windows.Forms.TextBox txt_apellido;
        private System.Windows.Forms.Label lbl_apellido;
        private System.Windows.Forms.TextBox txt_cuit;
        private System.Windows.Forms.Label lbl_cuit;
        private System.Windows.Forms.TextBox txt_mail;
        private System.Windows.Forms.Label lbl_mail;
        private System.Windows.Forms.TextBox txt_direccion;
        private System.Windows.Forms.Label lbl_direccion;
        private System.Windows.Forms.TextBox txt_localidad;
        private System.Windows.Forms.Label lbl_localidad;
        private System.Windows.Forms.TextBox txt_telefono;
        private System.Windows.Forms.Label lbl_telefono;
        private System.Windows.Forms.Button btn_salir;
        private System.Windows.Forms.Button btn_guardar;
        private System.Windows.Forms.Label lbl_situacion;
        private System.Windows.Forms.ComboBox cmb_situacion;
        private System.Windows.Forms.Label lbl_tipoproceso;
    }
}