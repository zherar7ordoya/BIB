﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Models;

namespace View
{
    public partial class Distribuidores : Form
    {
        public Distribuidores()
        {
            InitializeComponent();
        }

        private void Distribuidores_Load(object sender, EventArgs e)
        {
            
        }
    }
}
