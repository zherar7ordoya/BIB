﻿namespace View
{
    partial class frmLanguage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(588, 401);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 30);
            this.button1.TabIndex = 0;
            this.button1.Text = "Agregar";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(32, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(48, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Usuarios";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(145, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Patentes y flias.";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(292, 13);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(39, 13);
            this.label3.TabIndex = 3;
            this.label3.Text = "Menus";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(526, 13);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "Reparaciones";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(651, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(72, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "Aprobaciones";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(409, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(47, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Ingresos";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 43);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 20);
            this.textBox1.TabIndex = 8;
            this.textBox1.Text = "Usuarios";
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(12, 69);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 20);
            this.textBox2.TabIndex = 10;
            this.textBox2.Text = "Todos los usuarios";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(12, 95);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 20);
            this.textBox3.TabIndex = 12;
            this.textBox3.Text = "Configurar";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(12, 121);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(101, 20);
            this.textBox4.TabIndex = 14;
            this.textBox4.Text = "Agregar patentes";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(12, 147);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 20);
            this.textBox5.TabIndex = 16;
            this.textBox5.Text = "Agregar";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(12, 173);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 20);
            this.textBox6.TabIndex = 18;
            this.textBox6.Text = "Eliminar";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(12, 329);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 20);
            this.textBox7.TabIndex = 24;
            this.textBox7.Text = "Guardar cambios";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(12, 303);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(100, 20);
            this.textBox8.TabIndex = 23;
            this.textBox8.Text = "Permisos";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(12, 277);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(101, 20);
            this.textBox9.TabIndex = 22;
            this.textBox9.Text = "Resetear password";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(12, 251);
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(100, 20);
            this.textBox10.TabIndex = 21;
            this.textBox10.Text = "Eliminar";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(12, 225);
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(100, 20);
            this.textBox11.TabIndex = 20;
            this.textBox11.Text = "Agregar";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(12, 199);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(100, 20);
            this.textBox12.TabIndex = 19;
            this.textBox12.Text = "Agregar familias";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(265, 277);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(101, 20);
            this.textBox13.TabIndex = 34;
            this.textBox13.Text = "3. Salir";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(265, 251);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(100, 20);
            this.textBox14.TabIndex = 33;
            this.textBox14.Text = "2. C Aprobaciones";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(265, 225);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(100, 20);
            this.textBox15.TabIndex = 32;
            this.textBox15.Text = "2. B Reparaciones";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(265, 199);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(100, 20);
            this.textBox16.TabIndex = 31;
            this.textBox16.Text = "2. A Ingresos";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(265, 173);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(100, 20);
            this.textBox17.TabIndex = 30;
            this.textBox17.Text = "2. Maquinas";
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(265, 147);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(100, 20);
            this.textBox18.TabIndex = 29;
            this.textBox18.Text = "1. D Elegir idioma";
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(265, 121);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(101, 20);
            this.textBox19.TabIndex = 28;
            this.textBox19.Text = "1. C Idiomas";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(265, 95);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(100, 20);
            this.textBox20.TabIndex = 27;
            this.textBox20.Text = "1. B Patentes";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(265, 69);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(100, 20);
            this.textBox21.TabIndex = 26;
            this.textBox21.Text = "1.A Usuarios";
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(265, 43);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(100, 20);
            this.textBox22.TabIndex = 25;
            this.textBox22.Text = "1. Configuracion";
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(138, 329);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(100, 20);
            this.textBox23.TabIndex = 46;
            this.textBox23.Text = "Nombre";
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(138, 303);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(100, 20);
            this.textBox24.TabIndex = 45;
            this.textBox24.Text = "Nueva";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(138, 277);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(101, 20);
            this.textBox25.TabIndex = 44;
            this.textBox25.Text = "Eliminar";
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(138, 251);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(100, 20);
            this.textBox26.TabIndex = 43;
            this.textBox26.Text = "Agregar";
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(138, 225);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(100, 20);
            this.textBox27.TabIndex = 42;
            this.textBox27.Text = "Configurar";
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(138, 199);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(100, 20);
            this.textBox28.TabIndex = 41;
            this.textBox28.Text = "Todas las Familias";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(138, 173);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(100, 20);
            this.textBox29.TabIndex = 40;
            this.textBox29.Text = "Familias";
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(138, 147);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(100, 20);
            this.textBox30.TabIndex = 39;
            this.textBox30.Text = "Descripcion";
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(138, 121);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(101, 20);
            this.textBox31.TabIndex = 38;
            this.textBox31.Text = "Eliminar";
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(138, 95);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(100, 20);
            this.textBox32.TabIndex = 37;
            this.textBox32.Text = "Agregar";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(138, 69);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(100, 20);
            this.textBox33.TabIndex = 36;
            this.textBox33.Text = "Todas las patentes";
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(138, 43);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(100, 20);
            this.textBox34.TabIndex = 35;
            this.textBox34.Text = "Patentes";
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(137, 407);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(100, 20);
            this.textBox35.TabIndex = 49;
            this.textBox35.Text = "Guardar familia";
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(137, 381);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(100, 20);
            this.textBox36.TabIndex = 48;
            this.textBox36.Text = "Configurar familia";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(137, 355);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(101, 20);
            this.textBox37.TabIndex = 47;
            this.textBox37.Text = "Guardar";
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(392, 251);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(100, 20);
            this.textBox39.TabIndex = 58;
            this.textBox39.Text = "Generar remito";
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(392, 225);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(100, 20);
            this.textBox40.TabIndex = 57;
            this.textBox40.Text = "Ingresar maquina";
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(392, 199);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(100, 20);
            this.textBox41.TabIndex = 56;
            this.textBox41.Text = "Descripcion de la falla";
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(392, 173);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(100, 20);
            this.textBox42.TabIndex = 55;
            this.textBox42.Text = "Elementos incluidos";
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(392, 147);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(100, 20);
            this.textBox43.TabIndex = 54;
            this.textBox43.Text = "Descripcion";
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(392, 121);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(101, 20);
            this.textBox44.TabIndex = 53;
            this.textBox44.Text = "Color";
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(392, 95);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(100, 20);
            this.textBox45.TabIndex = 52;
            this.textBox45.Text = "Tipo de soldadura";
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(392, 69);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(100, 20);
            this.textBox46.TabIndex = 51;
            this.textBox46.Text = "Modelo";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(392, 43);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(100, 20);
            this.textBox47.TabIndex = 50;
            this.textBox47.Text = "Marca";
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(517, 147);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(100, 20);
            this.textBox48.TabIndex = 64;
            this.textBox48.Text = "Imposible reparar";
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(517, 121);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(101, 20);
            this.textBox49.TabIndex = 63;
            this.textBox49.Text = "Presupuestar";
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(517, 95);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(100, 20);
            this.textBox50.TabIndex = 62;
            this.textBox50.Text = "Revisada";
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(517, 69);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(100, 20);
            this.textBox51.TabIndex = 61;
            this.textBox51.Text = "Reparaciones";
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(517, 43);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(100, 20);
            this.textBox52.TabIndex = 60;
            this.textBox52.Text = "Maquinas";
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(644, 147);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(100, 20);
            this.textBox53.TabIndex = 69;
            this.textBox53.Text = "Rechazar";
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(644, 121);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(101, 20);
            this.textBox54.TabIndex = 68;
            this.textBox54.Text = "Aprobar";
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(644, 95);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(100, 20);
            this.textBox55.TabIndex = 67;
            this.textBox55.Text = "Reparaciones";
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(644, 69);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(100, 20);
            this.textBox56.TabIndex = 66;
            this.textBox56.Text = "Revisada";
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(644, 43);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(100, 20);
            this.textBox57.TabIndex = 65;
            this.textBox57.Text = "Maquina";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(669, 401);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 30);
            this.button2.TabIndex = 70;
            this.button2.Text = "Guardar";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(588, 375);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(156, 20);
            this.textBox58.TabIndex = 71;
            this.textBox58.TextChanged += new System.EventHandler(this.textBox58_TextChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(588, 356);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 72;
            this.label7.Text = "Nombre";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(588, 324);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(156, 21);
            this.comboBox1.TabIndex = 73;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(588, 300);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 13);
            this.label8.TabIndex = 74;
            this.label8.Text = "Seleccionar idioma";
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(645, 268);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(100, 20);
            this.textBox59.TabIndex = 75;
            // 
            // frmLanguage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 434);
            this.Controls.Add(this.textBox59);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.textBox58);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.textBox53);
            this.Controls.Add(this.textBox54);
            this.Controls.Add(this.textBox55);
            this.Controls.Add(this.textBox56);
            this.Controls.Add(this.textBox57);
            this.Controls.Add(this.textBox48);
            this.Controls.Add(this.textBox49);
            this.Controls.Add(this.textBox50);
            this.Controls.Add(this.textBox51);
            this.Controls.Add(this.textBox52);
            this.Controls.Add(this.textBox39);
            this.Controls.Add(this.textBox40);
            this.Controls.Add(this.textBox41);
            this.Controls.Add(this.textBox42);
            this.Controls.Add(this.textBox43);
            this.Controls.Add(this.textBox44);
            this.Controls.Add(this.textBox45);
            this.Controls.Add(this.textBox46);
            this.Controls.Add(this.textBox47);
            this.Controls.Add(this.textBox35);
            this.Controls.Add(this.textBox36);
            this.Controls.Add(this.textBox37);
            this.Controls.Add(this.textBox23);
            this.Controls.Add(this.textBox24);
            this.Controls.Add(this.textBox25);
            this.Controls.Add(this.textBox26);
            this.Controls.Add(this.textBox27);
            this.Controls.Add(this.textBox28);
            this.Controls.Add(this.textBox29);
            this.Controls.Add(this.textBox30);
            this.Controls.Add(this.textBox31);
            this.Controls.Add(this.textBox32);
            this.Controls.Add(this.textBox33);
            this.Controls.Add(this.textBox34);
            this.Controls.Add(this.textBox13);
            this.Controls.Add(this.textBox14);
            this.Controls.Add(this.textBox15);
            this.Controls.Add(this.textBox16);
            this.Controls.Add(this.textBox17);
            this.Controls.Add(this.textBox18);
            this.Controls.Add(this.textBox19);
            this.Controls.Add(this.textBox20);
            this.Controls.Add(this.textBox21);
            this.Controls.Add(this.textBox22);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox8);
            this.Controls.Add(this.textBox9);
            this.Controls.Add(this.textBox10);
            this.Controls.Add(this.textBox11);
            this.Controls.Add(this.textBox12);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "frmLanguage";
            this.Text = "frmLanguage";
            this.Load += new System.EventHandler(this.frmLanguage_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox59;
    }
}