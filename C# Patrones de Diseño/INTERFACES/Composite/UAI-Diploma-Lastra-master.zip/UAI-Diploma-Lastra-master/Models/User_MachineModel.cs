﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models
{
    public class User_MachineModel
    {
        public int Id_user { get; set; }
        public int Id_machine { get; set; }
        public int Time { get; set; }
    }
}
