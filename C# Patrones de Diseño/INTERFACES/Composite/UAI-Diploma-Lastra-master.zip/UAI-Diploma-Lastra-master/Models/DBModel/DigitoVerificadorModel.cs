﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.DBModel
{
    public class DigitoVerificadorModel
    {
        public string id_dv { get;set; }
        public string digitoVerificador { get;set; }    

    }
}
