﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.enums
{
    public enum MachineType
    {
        TIG_DC,
        TIG_AC,
        MIG,
        ELECTRODO
    }
}
