﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace UnitTests
{
    [TestClass]
    public class DBTests
    {
        [TestMethod]
        public void TestMethod1()
        {

        }
    }
}
