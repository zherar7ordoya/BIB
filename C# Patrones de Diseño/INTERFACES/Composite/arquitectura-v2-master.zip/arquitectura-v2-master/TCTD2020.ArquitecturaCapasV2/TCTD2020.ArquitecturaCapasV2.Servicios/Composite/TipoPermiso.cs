﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TCTD2020.ArquitecturaCapasV2.Servicios.Composite
{
    public enum TipoPermiso
    {
        GestorPermiso,
        GestorUsuario,
    }
}
