﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TCTD2020.ArquitecturaCapasV2.BE;

namespace TCTD2020.ArquitecturaCapasV2.DAL
{
    public class UsuarioDAL : AbstractDAL<Usuario>
    {
    }
}
