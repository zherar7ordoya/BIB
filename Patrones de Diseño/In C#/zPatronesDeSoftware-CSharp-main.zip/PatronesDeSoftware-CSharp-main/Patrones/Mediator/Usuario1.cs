﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator.Chat
{
    public class Usuario1 : Usuario
    {
        public Usuario1(string _nombre) : base(_nombre) {}
    }
}
