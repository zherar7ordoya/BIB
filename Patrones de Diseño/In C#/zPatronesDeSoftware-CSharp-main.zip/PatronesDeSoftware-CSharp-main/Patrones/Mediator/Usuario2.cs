﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mediator.Chat
{
    public class Usuario2 : Usuario
    {
        public Usuario2(string _nombre) : base(_nombre) { }
    }
}
