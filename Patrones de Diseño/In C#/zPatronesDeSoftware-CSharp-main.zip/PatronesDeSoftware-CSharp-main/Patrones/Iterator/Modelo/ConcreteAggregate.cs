﻿
namespace PdC_04_Iterator
{
    public class ConcreteAggregate : Aggregate
    {
        public override void CreateIterator()
        {
        }
    }
}