﻿
namespace PdC_04_Iterator
{
    public class ConcreteIterator : Iterator
    {
        public ConcreteIterator(Aggregate _aggregate)
        {
        }

        public override void Current()
        {
        }

        public override void First()
        {
        }

        public override void IsDone()
        {
        }

        public override void Siguiente()
        {
        }
    }
}