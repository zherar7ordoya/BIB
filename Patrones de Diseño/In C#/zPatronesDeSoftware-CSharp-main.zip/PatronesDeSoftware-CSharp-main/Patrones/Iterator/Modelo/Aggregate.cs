﻿
namespace PdC_04_Iterator
{
    public abstract class Aggregate
    {
        public abstract void CreateIterator();
    }
}