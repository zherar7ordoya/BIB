﻿
namespace PdC_04_Iterator
{
    public abstract class Iterator
    {
        public abstract void First();
        public abstract void Siguiente();
        public abstract void IsDone();
        public abstract void Current();
    }
}