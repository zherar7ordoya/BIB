==========================Exercise Checking Report==========================
Exercise No...........: 4
First Student Details.: 312270887 - Yuval Raz.
Second Student Details: 316522408 - Lior Chen.
Delivery Date.........: 16.6.2020
Delivered In Delay....: No.
Delay Reason..........: None.
Visual Studio Version.: 2019.
Comments..............: None.
=======================End Exercise Checking Report=========================