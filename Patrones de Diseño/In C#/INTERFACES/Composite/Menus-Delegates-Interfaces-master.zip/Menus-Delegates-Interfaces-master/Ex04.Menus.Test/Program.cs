﻿namespace Ex04.Menus.Test
{
    public static class Program
    {
        public static void Main()
        {
            RunMenuByDelegates.ActiveMenu();
            RunMenuByInterfaces.ActiveMenu();
        }
    }
}
