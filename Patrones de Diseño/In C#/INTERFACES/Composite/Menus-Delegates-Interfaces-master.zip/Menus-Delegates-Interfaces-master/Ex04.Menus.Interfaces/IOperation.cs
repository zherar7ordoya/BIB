﻿namespace Ex04.Menus.Interfaces
{
    public interface IOperation
    {
        void OperationFromSystem();
    }
}
