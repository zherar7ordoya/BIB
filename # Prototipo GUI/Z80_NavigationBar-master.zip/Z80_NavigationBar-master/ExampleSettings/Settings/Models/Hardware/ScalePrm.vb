﻿Namespace ParamModels

    Public Class ScalePrm
        Public Property ID As Integer
        Public Property Protocol As String
    End Class

End Namespace
