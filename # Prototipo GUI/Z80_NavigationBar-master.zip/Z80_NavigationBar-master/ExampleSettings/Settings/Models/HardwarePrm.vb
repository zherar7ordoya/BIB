﻿Namespace ParamModels

    Public Class HardwarePrm
        Public Scales As List(Of ScalePrm)
        Public TemperatureSensor As TempSensorPrm
    End Class

End Namespace
