﻿Public NotInheritable Class AppGlobals

    Public Const PARAM_FILE As String = "Z80NavBar_exampleSettings.xml"

    Public Shared Prm As Settings

End Class
