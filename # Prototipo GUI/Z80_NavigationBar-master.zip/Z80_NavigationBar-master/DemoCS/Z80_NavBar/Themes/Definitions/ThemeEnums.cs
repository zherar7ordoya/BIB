﻿namespace Z80NavBar.Themes
{

    /// <summary>
    /// Z80_Navigation control theme enumerations
    /// </summary>
    public enum Theme
    {

        // Note: If you implement more themes or your own themes, just add enumeration here

        Dark = 0,
        Blue
    }

}
