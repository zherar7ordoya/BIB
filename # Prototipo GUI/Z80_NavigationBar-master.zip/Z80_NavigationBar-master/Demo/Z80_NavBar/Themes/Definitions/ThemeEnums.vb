﻿Namespace Z80NavBar.Themes

    ''' <summary>
    ''' Z80_Navigation control theme enumerations
    ''' </summary>
    Public Enum Theme

        ' Note: If you implement more themes or your own themes, just add enumeration here

        Dark = 0
        Blue
    End Enum

End Namespace
